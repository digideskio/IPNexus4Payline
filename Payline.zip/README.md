## Payline Payment Method
Payline is an Iranian payment method. This gateway is for IP.Nexus 4.x


### How To Install

1. Upload all contents of `Upload` folder to IPS4 root folder
2. Install plugin file from `Admin CP > System > Site Features > Plugins > Install`